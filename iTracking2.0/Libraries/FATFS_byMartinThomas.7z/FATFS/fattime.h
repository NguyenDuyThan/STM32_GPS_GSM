#ifndef FATTIME_H_
#define FATTIME_H_

unsigned long get_fattime (void);

#endif
