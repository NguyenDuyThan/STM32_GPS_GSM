/*-----------------------------------------------------------------------*/
/* Low level disk I/O module skeleton for FatFs     (C)ChaN, 2016        */
/*-----------------------------------------------------------------------*/
/* If a working storage control module is available, it should be        */
/* attached to the FatFs via a glue function rather than modifying it.   */
/* This is an example of glue functions to attach various exsisting      */
/* storage control modules to the FatFs module with a defined API.       */
/*-----------------------------------------------------------------------*/
/*-----------------------------------------------------------------------
 * Author: To Hoa Duy Vinh
 * Company: Dinh Vi So
 * Attention: this file is heavily coding based on only for iTracking2.0 hardware.
 *
 *-----------------------------------------------------------------------*/
/*##################################################################################
 * INCLUDE
 *##################################################################################*/
#include "string.h"
#include "diskio.h"		/* FatFs lower layer API */
#include "NORflash.h"
#include "FreeRTOS.h" // We need delay function
#include "task.h"
#include "STM32F1_io.h"
#include "STM32F1_spi.h"
#include "STM32F1_tim.h"
#include "NORflash_branchInfo.h"
#include "dbgPrint.h"
#include "HWmapping_iTrackingV2.3.h"

#include "stm32f10x_iwdg.h"
/*##################################################################################
 * DEFINES
 *##################################################################################*/
/* Definitions of physical drive number for each drive */
// Must matching with order in _VOLUME_STRS (ffconf.h)
#define PDRV_NORFL	0
#define PDRV_SDC	1

#define NORFL_SECTOR_SIZE						_4K_
#define NORFL_BLOCK_SIZE						_4K_
#define NORFL_SECTOR_COUNT						(CYPRESS_S25FL256S_256Mb_TOTAL_SIZE / NORFL_SECTOR_SIZE)
/*##################################################################################
 * TYPEDEFS
 *##################################################################################*/

/*##################################################################################
 * FUNC.PROTOTYPES
 *##################################################################################*/

/*##################################################################################
 * VARIABLES
 *##################################################################################*/
static BYTE NORfl_init = 0;
static DWORD _1msTickCt = 0;
/*##################################################################################
 * FUNCTIONS
 *##################################################################################*/
/*--------------------------------------------------------------------------
 * Brief: Delay millisecond
 * Param:	t	|	I	|	delay time
 ---------------------------------------------------------------------------*/
void TIM2_tickCB(void)
{
	_1msTickCt++;
}
/*--------------------------------------------------------------------------
 * Brief: Delay millisecond
 * Param:	t	|	I	|	delay time
 ---------------------------------------------------------------------------*/
void delayms(DWORD t)
{
	_1msTickCt = 0;
	while(_1msTickCt <= t);
//	if (t < 10)
//	{
//		t = 10;
//	}
//	vTaskDelay(t / 10);
}
/*--------------------------------------------------------------------------
 * Brief:
 ---------------------------------------------------------------------------*/
void NORFL_wrtCSpin(BYTE val)
{
	IO_wrt(EXTFLASH_CS_PORT, EXTFLASH_CS_PIN, val);
}
/*--------------------------------------------------------------------------
 * Brief:
 ---------------------------------------------------------------------------*/
uint8_t NORFL_wrSPI(uint8_t dat)
{
	return SPI_wr1Byte(1, dat);
}
/*-----------------------------------------------------------------------*/
/* Get Drive Status                                                      */
/*-----------------------------------------------------------------------*/

DSTATUS disk_status (
	BYTE pdrv		/* Physical drive nmuber to identify the drive */
)
{
	switch (pdrv)
	{
		case PDRV_NORFL:
		{
			U8 manId, memType, memCap;
			if (!NORfl_init)
			{
				return STA_NOINIT;
			}
			NORFL_readId(&manId, &memType, &memCap, 0, NULL);
			if ((manId != CYPRESS_MANID) //
					|| (memType != CYPRESS_S25FL256S_256Mb_MEMTYPE) //
					|| (memCap != CYPRESS_S25FL256S_256Mb_MEMCAP))
			{
				return STA_NODISK;
			}
			return STA_OK;
		}
	}
	return STA_NODISK;
}



/*-----------------------------------------------------------------------*/
/* Inidialize a Drive                                                    */
/*-----------------------------------------------------------------------*/

DSTATUS disk_initialize (
	BYTE pdrv				/* Physical drive nmuber to identify the drive */
)
{
	switch (pdrv)
	{
		case PDRV_NORFL:
		{
			U8 manId, memType, memCap;

			SPI_setup(1, 1, SPI_SPEED_HIGH);
			/* Setup timer 2: use for delay 1ms */
			TIM_setup(2, TIMFREQ_1KHz, TIM2_tickCB);
			NORFL_setup_dbgPrt(DBG_print);
			NORFL_setup(delayms, NORFL_wrSPI, NORFL_wrtCSpin, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, CYPRESS_S25FL256S_256Mb_SECTOR_SIZE);
			NORFL_readId(&manId, &memType, &memCap, 0, NULL);
			//DBG_print("\r\n disk_initialize:%X,%X,%X", manId, memType, memCap);
			if ((manId != CYPRESS_MANID) //s
					|| (memType != CYPRESS_S25FL256S_256Mb_MEMTYPE) //
					|| (memCap != CYPRESS_S25FL256S_256Mb_MEMCAP))
			{
				return STA_NODISK;
			}
			NORfl_init = 1;
#if 1
			{
				U8 dat[CYPRESS_S25FL256S_256Mb_PAGE_SIZE], res;
				U32 addr = 0;
				while (1)
				{
					DBG_print("\r\n ----- A=%u -----", addr);
					/* Generate data */
					DBG_print("\r\n<WRT>\r\n");
					for (U32 i = 0; i < CYPRESS_S25FL256S_256Mb_PAGE_SIZE; i++)
					{
						dat[i] = (i + addr) % 0xFF;
						DBG_print("%02X", dat[i]);
					}
					DBG_print("\r\n</WRT>\r\n");
					res = NORFL_cmpDat(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, dat);
					DBG_print("\r\n disk_initialize:CMP:%u", res);
					if (res)
					{
						/* Erase */
						res = NORFL_erase4kB(addr, 500);
						DBG_print("\r\n disk_initialize:ER:%u", res);
						/* Write */
						res = NORFL_progPg(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, dat, 500);
						DBG_print("\r\n disk_initialize:PP:%u", res);
						/* Clear buffer */
						memset(dat, 0, CYPRESS_S25FL256S_256Mb_PAGE_SIZE);
						/* Read data */
						res = NORFL_rdDat(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, dat);
						DBG_print("\r\n disk_initialize:RD:%u", res);
						DBG_print("\r\n<RD>\r\n");
						for (U32 i = 0; i < CYPRESS_S25FL256S_256Mb_PAGE_SIZE; i++)
						{
							DBG_print("%02X", dat[i]);
						}
						DBG_print("\r\n</RD>\r\n");
					}
					/* Increase address */
					addr += 4096;//4096 * 64;
					if (addr >= (256 * 4096))
					{
						break;
					}
				}
				while (1)
				{
					IWDG_ReloadCounter();
				}
			}
#endif
			return STA_OK;
		}
	}
	return STA_NODISK;
}



/*-----------------------------------------------------------------------*/
/* Read Sector(s)                                                        */
/*-----------------------------------------------------------------------*/

DRESULT disk_read (
	BYTE pdrv,		/* Physical drive nmuber to identify the drive */
	BYTE *buff,		/* Data buffer to store read data */
	DWORD sector,	/* Sector address in LBA */
	UINT count		/* Number of sectors to read */
)
{
	switch (pdrv)
	{
		case PDRV_NORFL:
		{
			if (!NORfl_init)
			{
				DBG_print("\r\n disk_read:NOTRDY");
				return RES_NOTRDY;
			}
			IWDG_ReloadCounter();
			DBG_print("\r\n disk_read:%u,%u", sector, count);
			if (NORFL_rdDat(sector * NORFL_SECTOR_SIZE, count * NORFL_SECTOR_SIZE, buff))
			{
				DBG_print("\r\n disk_read:ERR");
				return RES_ERROR;
			}
			return RES_OK;
		}
	}

	return RES_PARERR;
}



/*-----------------------------------------------------------------------*/
/* Write Sector(s)                                                       */
/*-----------------------------------------------------------------------*/

DRESULT disk_write (
	BYTE pdrv,			/* Physical drive nmuber to identify the drive */
	const BYTE *buff,	/* Data to be written */
	DWORD sector,		/* Sector address in LBA */
	UINT count			/* Number of sectors to write */
)
{
	switch (pdrv)
	{
		case PDRV_NORFL:
		{
			DWORD addr = sector * NORFL_SECTOR_SIZE, ofs = 0;
			BYTE res, rDat[NORFL_SECTOR_SIZE];

			if (!NORfl_init)
			{
				DBG_print("\r\n disk_write:NOTRDY");
				return RES_NOTRDY;
			}
			DBG_print("\r\n disk_write:%u,%u", sector, count);
			IWDG_ReloadCounter();
			while(1)
			{
#if AVOID_NONUPDATED_WRT == 0
				if (addr % NORFL_SECTOR_SIZE)
				{
					res = NORFL_cmpDat(addr, NORFL_SECTOR_SIZE, rDat);
					DBG_print("\r\n disk_write:Cmp:E=%u", res);
					if (!res)
					{
						addr += NORFL_SECTOR_SIZE;
						ofs += NORFL_SECTOR_SIZE;
						DBG_print("\r\n disk_write:Non-updated_data");
						continue;
					}
				}
#endif
				res = NORFL_erase4kB(addr, 500);
				if (res)
				{
					DBG_print("\r\n disk_write:Erase A=%X:E=%u", addr, res);
					if (res != 0xFF)
					{
						return RES_ERROR;
					}
				}
				else
				{
					memset(rDat, 0 , NORFL_SECTOR_SIZE);
					res = NORFL_rdDat(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, rDat);
					if (res)
					{
						DBG_print("\r\n disk_write:RD:E=%u", res);
						return RES_ERROR;
					}
					DBG_print("\r\n<RDAE>\r\n");
					for (U32 i = 0; i < CYPRESS_S25FL256S_256Mb_PAGE_SIZE; i++)
					{
						DBG_print("%02X", rDat[i]);
					}
					DBG_print("\r\n</RDAE>");
				}
				res = NORFL_progPg(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, &buff[ofs], 500);
				if (res)
				{
					DBG_print("\r\n disk_write:PP:E=%u", res);
					return RES_ERROR;
				}
#if AVOID_VERIFY_AFTER_WRT == 0
				memset(rDat, 0 , NORFL_SECTOR_SIZE);
				res = NORFL_rdDat(addr, CYPRESS_S25FL256S_256Mb_PAGE_SIZE, rDat);
				if (res)
				{
					DBG_print("\r\n disk_write:RD:E=%u", res);
					return RES_ERROR;
				}
				if (memcmp(rDat, &buff[ofs], CYPRESS_S25FL256S_256Mb_PAGE_SIZE))
				{
					DBG_print("\r\n<WRT>\r\n");
					for (U32 i = 0; i < CYPRESS_S25FL256S_256Mb_PAGE_SIZE; i++)
					{
						DBG_print("%02X", buff[ofs + i]);
					}
					DBG_print("\r\n</WRT>");
					DBG_print("\r\n<RD>\r\n");
					for (U32 i = 0; i < CYPRESS_S25FL256S_256Mb_PAGE_SIZE; i++)
					{
						DBG_print("%02X", rDat[i]);
					}
					DBG_print("\r\n</RD>");
					DBG_print("\r\n disk_write:A=%X O=%u", addr, ofs);
					DBG_print("\r\n disk_write:written data is not matched");
					return RES_ERROR;
				}
#endif
				addr += CYPRESS_S25FL256S_256Mb_PAGE_SIZE;
				ofs += CYPRESS_S25FL256S_256Mb_PAGE_SIZE;
				if (ofs >= (count * NORFL_SECTOR_SIZE))
				{
					break;
				}
			}
			return RES_OK;
		}
	}

	return RES_PARERR;
}



/*-----------------------------------------------------------------------*/
/* Miscellaneous Functions                                               */
/*-----------------------------------------------------------------------*/

DRESULT disk_ioctl (
	BYTE pdrv,		/* Physical drive nmuber (0..) */
	BYTE cmd,		/* Control code */
	void *buff		/* Buffer to send/receive control data */
)
{
	switch (pdrv)
	{
		case PDRV_NORFL:
		{
			if (!NORfl_init)
			{
				return RES_NOTRDY;
			}
			switch (cmd)
			{
				case CTRL_SYNC: /* Do nothing */
					break;
				case GET_SECTOR_COUNT:
					DBG_print("\r\n SectorCount=%u", NORFL_SECTOR_COUNT);
					*(DWORD*)buff = NORFL_SECTOR_COUNT;
					break;
				case GET_SECTOR_SIZE:
					DBG_print("\r\n SectorSize=%u", NORFL_SECTOR_SIZE);
					*(DWORD*)buff = NORFL_SECTOR_SIZE;
					break;
				case GET_BLOCK_SIZE:
					DBG_print("\r\n BlockSize=%u", NORFL_BLOCK_SIZE);
					*(DWORD*)buff = NORFL_BLOCK_SIZE;
					break;
#if _USE_TRIM
				case CTRL_TRIM:
					break;
#endif /* _USE_TRIM */
			}
			return RES_OK;
		}
	}

	return RES_PARERR;
}

